CALEB'S GENERATIVE AI INNOVATION WEBSITE

Files:
- index.html: the complete responsive website.

HOW TO PREVIEW:
1. Extract the ZIP file.
2. Open index.html in a browser.

HOW TO GET A PUBLIC WEBSITE LINK FOR YOUR FORM:
1. Create/sign in to a GitHub account at https://github.com/
2. Create a new public repository named: caleb-genai-innovation
3. Upload index.html to the repository's main/root folder.
4. Open the repository's Settings -> Pages.
5. Under Build and deployment, choose "Deploy from a branch".
6. Select branch "main" and folder "/ (root)", then Save.
7. Wait for GitHub Pages to publish the site. It will show a public link similar to:
   https://YOUR-USERNAME.github.io/caleb-genai-innovation/
8. Open that link to confirm it works, then use the public link in the "Website of Innovation" form field.

IMPORTANT:
- Replace YOUR-USERNAME with your actual GitHub username; do not submit the example link.
- This is a project showcase page, not a fully hosted AI assistant. The project is described honestly as a student prototype in development.
- Do not put API keys, passwords, or private information in the website or public repository.
